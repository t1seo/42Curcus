/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tseo <tseo@student.42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/01/02 23:51:33 by tseo              #+#    #+#             */
/*   Updated: 2021/01/08 12:11:57 by tseo             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./mlx/mlx.h"
#include <math.h>
#include <stdlib.h>

#include <stdio.h>

/*
** Keys of Mac OS
*/
#define KEY_W 13
#define KEY_A 0
#define KEY_S 1
#define KEY_D 2
#define KEY_AR_L 123
#define KEY_AR_R 124
#define KEY_ESC 53

#define X_EVENT_KEY_PRESS 2
#define X_EVENT_KEY_EXIT 17
#define TEX_WIDTH 64
#define TEX_HEIGHT 64
#define MAP_WIDTH 24
#define MAP_HEIGHT 24
#define SCREEN_WIDTH 640
#define SCREEN_HEIGHT 480

#define NUM_SPRITES 19

typedef struct s_img
{
	void *img;
	int *data;
	int size_l;
	int bpp;
	int endian;
	int img_width;
	int img_height;
} t_img;

typedef struct s_vec
{
	double x;
	double y;
} t_vec;

typedef struct s_sprite
{
	t_vec sprite_pos;
	int texture;
} t_sprite;

t_sprite sprite[2] =
	{
		// green light in front of the player start
		{{20.5, 11.5}, 10},

		// green lights in every room
		{{18.5, 4.5}, 10},
		{{10.0, 4.5}, 10},
		{{10.0, 12.5}, 10},
		{{3.5, 6.5}, 10},
		{{3.5, 20.5}, 10},
		{{3.5, 14.5}, 10},
		{{14.5, 20.5}, 10},

		//row of pillars in front of wall: fisheye test
		{{18.5, 10.5}, 9},
		{{18.5, 11.5}, 9},
		{{18.5, 12.5}, 9},

		//some barrels around the map
		{{15.5, 1.5}, 8},
		{{21.5, 1.5}, 8},
		{{16.0, 1.8}, 8},
		{{16.2, 1.2}, 8},
		{{3.5, 2.5}, 8},
		{{9.5, 15.5}, 8},
		{{10.0, 15.1}, 8},
		{{10.5, 15.8}, 8},
};

int sprite_order[NUM_SPRITES];
double sprite_distance[NUM_SPRITES];

typedef struct s_key
{
	int key_a;
	int key_w;
	int key_s;
	int key_d;
	int key_esc;
} t_key;

typedef struct s_info
{
	t_vec player_pos;
	t_vec dir_vec;
	t_vec plane_vec;
	void *mlx;
	void *win;
	t_key keys;
	t_img img;
	int buf[SCREEN_HEIGHT][SCREEN_WIDTH];
	double z_buffer[SCREEN_WIDTH];
	int **texture;
	double move_speed;
	double rot_speed;
} t_info;

typedef struct s_pair
{
	double first;
	int second;
} t_pair;

static int compare(const void *first, const void *second)
{
	if (*(int *)first > *(int *)second)
		return (1);
	else if (*(int *)first > *(int *)second)
		return (-1);
	else
		return (0);
}

// sort sprites as distance using bubble sort
void sort_sprites_order(t_pair *orders, int num_sprites)
{
	t_pair tmp;
	int i;
	int j;

	i = -1;
	while (++i < num_sprites)
	{
		j = -1;
		while (++j < num_sprites - 1)
		{
			if (orders[j].first < orders[j + 1].first)
			{
				tmp = orders[j];
				orders[j] = orders[j + 1];
				orders[j + 1] = tmp;
			}
		}
	}
}

// sort sprites
void sort_sprites(int *order, double *dist, int num_sprites)
{
	t_pair *sprites;
	int i;

	if (!(sprites = (t_pair *)malloc(sizeof(t_pair) * num_sprites)))
		return;
	i = -1;
	while (++i < num_sprites)
	{
		sprites[i].first = dist[i];
		sprites[i].second = order[i];
	}
	sort_sprites_order(sprites, num_sprites);
	i = -1;
	while (++i < num_sprites)
	{
		dist[i] = sprites[num_sprites - i - 1].first;
		order[i] = sprites[num_sprites - i - 1].second;
	}
	free(sprites);
}

int world_map[MAP_WIDTH][MAP_HEIGHT] =
	{
		{8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 4, 4, 6, 4, 4, 6, 4, 6, 4, 4, 4, 6, 4},
		{8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4},
		{8, 0, 3, 3, 0, 0, 0, 0, 0, 8, 8, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6},
		{8, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6},
		{8, 0, 3, 3, 0, 0, 0, 0, 0, 8, 8, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4},
		{8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 4, 0, 0, 0, 0, 0, 6, 6, 6, 0, 6, 4, 6},
		{8, 8, 8, 8, 0, 8, 8, 8, 8, 8, 8, 4, 4, 4, 4, 4, 4, 6, 0, 0, 0, 0, 0, 6},
		{7, 7, 7, 7, 0, 7, 7, 7, 7, 0, 8, 0, 8, 0, 8, 0, 8, 4, 0, 4, 0, 6, 0, 6},
		{7, 7, 0, 0, 0, 0, 0, 0, 7, 8, 0, 8, 0, 8, 0, 8, 8, 6, 0, 0, 0, 0, 0, 6},
		{7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 6, 0, 0, 0, 0, 0, 4},
		{7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 6, 0, 6, 0, 6, 0, 6},
		{7, 7, 0, 0, 0, 0, 0, 0, 7, 8, 0, 8, 0, 8, 0, 8, 8, 6, 4, 6, 0, 6, 6, 6},
		{7, 7, 7, 7, 0, 7, 7, 7, 7, 8, 8, 4, 0, 6, 8, 4, 8, 3, 3, 3, 0, 3, 3, 3},
		{2, 2, 2, 2, 0, 2, 2, 2, 2, 4, 6, 4, 0, 0, 6, 0, 6, 3, 0, 0, 0, 0, 0, 3},
		{2, 2, 0, 0, 0, 0, 0, 2, 2, 4, 0, 0, 0, 0, 0, 0, 4, 3, 0, 0, 0, 0, 0, 3},
		{2, 0, 0, 0, 0, 0, 0, 0, 2, 4, 0, 0, 0, 0, 0, 0, 4, 3, 0, 0, 0, 0, 0, 3},
		{1, 0, 0, 0, 0, 0, 0, 0, 1, 4, 4, 4, 4, 4, 6, 0, 6, 3, 3, 0, 0, 0, 3, 3},
		{2, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 1, 2, 2, 2, 6, 6, 0, 0, 5, 0, 5, 0, 5},
		{2, 2, 0, 0, 0, 0, 0, 2, 2, 2, 0, 0, 0, 2, 2, 0, 5, 0, 5, 0, 0, 0, 5, 5},
		{2, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 2, 5, 0, 5, 0, 5, 0, 5, 0, 5},
		{1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5},
		{2, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 2, 5, 0, 5, 0, 5, 0, 5, 0, 5},
		{2, 2, 0, 0, 0, 0, 0, 2, 2, 2, 0, 0, 0, 2, 2, 0, 5, 0, 5, 0, 0, 0, 5, 5},
		{2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 5, 5, 5, 5, 5, 5, 5, 5, 5}};

void draw(t_info *info)
{
	int y;
	int x;

	y = -1;
	while (++y < SCREEN_HEIGHT)
	{
		x = -1;
		while (++x < SCREEN_WIDTH)
		{
			info->img.data[y * SCREEN_WIDTH + x] = info->buf[y][x];
		}
	}
	mlx_put_image_to_window(info->mlx, info->win, info->img.img, 0, 0);
}

void calc(t_info *info)
{
	// FLOOR AND CEIL
	int x;
	int y;
	x = -1;
	while (++x < SCREEN_WIDTH)
	{
		y = -1;
		while (++y < SCREEN_HEIGHT)
		{
			info->buf[y][x] = 0xFFFFFF;						// Floor(white)
			info->buf[SCREEN_HEIGHT - y - 1][x] = 0x000000; // Ceil(black)
		}
	}

	// WALL CASTING
	x = -1;
	while (++x < SCREEN_WIDTH)
	{
		// x-coordiante of camra space (-1 ~ 1)
		double camera_x = 2 * x / (double)SCREEN_WIDTH - 1;

		// ray direction vector
		t_vec ray_dir;
		ray_dir.x = info->dir_vec.x + info->plane_vec.x * camera_x;
		ray_dir.y = info->dir_vec.y + info->plane_vec.y * camera_x;

		// which box of the map player in
		int map_x = (int)info->player_pos.x;
		int map_y = (int)info->player_pos.y;

		// length of ray from current player position to next x or y-side
		t_vec side_dist;

		// length of ray from one x or y-side to next x or y-side
		t_vec delta_dist;
		delta_dist.x = fabs(1 / ray_dir.x);
		delta_dist.y = fabs(1 / ray_dir.y);

		// perpendicular distance from camera plane to hit point
		double perp_wall_dist;

		// which direction to step in x or y-direction (either +1 or -1)
		int step_x;
		int step_y;

		// was there a wall hit?
		int hit;
		hit = 0;

		// was a NS of a EW wall hit?
		int side;

		// calculate step and initial side_dist
		if (ray_dir.x < 0)
		{
			step_x = -1;
			side_dist.x = (info->player_pos.x - map_x) * delta_dist.x;
		}
		else
		{
			step_x = 1;
			side_dist.x = (map_x + 1.0 - info->player_pos.x) + delta_dist.x;
		}
		if (ray_dir.y < 0)
		{
			step_y = -1;
			side_dist.y = (info->player_pos.y - map_y) * delta_dist.y;
		}
		else
		{
			step_y = 1;
			side_dist.y = (map_y + 1.0 - info->player_pos.y) * delta_dist.y;
		}

		// perform DDA
		while (hit == 0)
		{
			// jump to next map square, OR in x-direction, OR in y-direction
			if (side_dist.x < side_dist.y)
			{
				side_dist.x += delta_dist.x;
				map_x += step_x;
				side = 0;
			}
			else
			{
				side_dist.y += delta_dist.y;
				map_y += step_y;
				side = 1;
			}
			// check if ray has hit a wall
			if (world_map[map_x][map_y] > 0)
				hit = 1;
		}

		// Calculate distance of perpendicular ray (Euclidean distance will give fisheye effect)
		if (side == 0)
			perp_wall_dist = (map_x - info->player_pos.x + (1 - step_x) / 2) / ray_dir.x;
		else
			perp_wall_dist = (map_y - info->player_pos.y + (1 - step_y) / 2) / ray_dir.y;

		// calculate height of line to draw on screen
		int line_height = (int)(SCREEN_HEIGHT / perp_wall_dist);

		// calculate lowest and highest pixel to fill in current stripe
		int draw_start = -line_height / 2 + SCREEN_HEIGHT / 2;

		if (draw_start > 0)
			draw_start = 0;

		int draw_end = line_height / 2 + SCREEN_HEIGHT / 2;

		// texturing calcultaions
		int tex_num = world_map[map_x][map_y] - 1; // 1 substracted from it so that texture 0 can be used

		// calculate value of wall_x
		double wall_x; // where exactly the wall was hit
		if (side == 0)
			wall_x = info->player_pos.y + perp_wall_dist * ray_dir.y;
		else
			wall_x = info->player_pos.x + perp_wall_dist * ray_dir.x;
		wall_x -= floor(wall_x);

		// x coordinate on the texture
		int tex_x = (int)(wall_x * (double)TEX_WIDTH);
		if (side == 0 && ray_dir.x > 0)
			tex_x = TEX_WIDTH - tex_x - 1;
		if (side == 1 && ray_dir.y < 0)
			tex_x = TEX_WIDTH - tex_x - 1;

		// How much to increase the texture coordinate per screen pixel
		double step = 1.0 * TEX_HEIGHT / line_height;

		// starting texture coordinate
		double tex_pos = (draw_start - SCREEN_HEIGHT / 2 + line_height / 2) * step;

		y = draw_start;
		while (y < draw_end)
		{
			// cast the texture coordinate to integer, and mask with (TEX_HEIGHT - 1) in case of overflow
			int tex_y = (int)tex_pos & (TEX_HEIGHT - 1);
			tex_pos += step;
			int color = info->texture[tex_num][TEX_HEIGHT * tex_y + tex_x];
			// make color darker for y-sides: R, G and B byte each divided throigh two with a "shift" and an "and"
			if (side == 1)
				color = (color >> 1) & 8355711;
			info->buf[y][x] = color;
			y++;
		}
		// SET THE ZBUFFER FOR THE SPRITE CASTING
		info->z_buffer[x] = perp_wall_dist; // perpendicular distance is used
	}

	// SPRITE CASTING
	// sort sprites from far to close
	int i;
	i = 0;
	while (i < NUM_SPRITES)
	{
		sprite_order[i] = i;
		sprite_distance[i] = ((info->player_pos.x - sprite[i].sprite_pos.x) * (info->player_pos.x - sprite[i].sprite_pos.x) + (info->player_pos.y - sprite[i].sprite_pos.y) * (info->player_pos.y - sprite[i].sprite_pos.y));
		i++;
	}

	sort_sprites(sprite_order, sprite_distance, NUM_SPRITES);

	// after sorting the srites, do the projection and draw them
	i = 0;
	while (i < NUM_SPRITES)
	{
		// translate sprite position to relative to camera
		t_vec sprite_to_camera;
		sprite_to_camera.x = sprite[sprite_order[i]].sprite_pos.x - info->player_pos.x;
		sprite_to_camera.y = sprite[sprite_order[i]].sprite_pos.y - info->player_pos.y;

		// transform sprite with the inverse camera matrix
		
		i++;
	}
}
