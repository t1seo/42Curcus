#include <stdio.h>

extern int x;
extern int y;

int add();
