#include <stdio.h>

typedef union u_dlbe
{
	double value;
	struct
	{
		size_t m : 52;
		size_t e : 11;
		size_t s : 1;
	} s_int;
} t_dble;


int main(void)
{
	t_dble v;
	v.value = 0.4;

	printf("%zu\n", v.s_int.m);
	printf("%d\n", v.s_int.e);
	printf("%d\n", v.s_int.s);
}

