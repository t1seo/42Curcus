#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(void)
{
	char *str = "1920 1080";
	printf("%d %d\n", atoi(str), atoi(str));
}
