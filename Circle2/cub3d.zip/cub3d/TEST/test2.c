#include <stdio.h>

int main(void)
{
	char str[20] = "Hello, world";
	char *ptr = &str[2];

	printf("%s\n", str);
	printf("%s\n", ptr);
}
