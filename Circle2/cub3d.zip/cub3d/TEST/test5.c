#include <stdio.h>

int main(void)
{
	int color = 0;
	int r = 255;
	int g = 255;
	int b = 255;
	color |= (r << 16);
	color |= (g << 8);
	color |= b;

	printf("%d\n", color);
}
