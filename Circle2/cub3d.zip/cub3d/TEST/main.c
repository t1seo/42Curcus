#include "head.h"

int x = 10;
int y = 20;

int main(void)
{
	int result = add();
	printf("%d\n", result);
}
