#include "head.h"

int add(void)
{
	int a = x;
	int b = y;
	return a + b;
}
